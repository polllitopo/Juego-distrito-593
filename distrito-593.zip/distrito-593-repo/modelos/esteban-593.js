// =====================================================================
//  DISTRITO 593 — Esteban Benavides (versión detallada)
//  Modelo 3D de escala humana real (1 unidad = 1 metro, ~1.74 m de alto)
//  hecho con Three.js a partir de las fotos de referencia.
//
//  Uso:
//    import { createEsteban593 } from './esteban-593.js';
//    const p = createEsteban593();
//    scene.add(p);
//    p.userData.play('walk');           // 'idle' | 'walk' | 'run' | 'punch' | 'drive'
//    // en el loop:
//    p.userData.update(dt);
//
//  Velocidades sugeridas para moverlo en el mundo (m/s):
//    p.userData.speeds  ->  { walk: 1.45, run: 5.2 }
//  Con 'drive' la cadera queda a p.userData.seatHeight sobre el origen:
//    colócalo en el asiento del auto con  p.position.y = asientoY - seatHeight.
//
//  Mira hacia +Z, pies en y = 0.  Las articulaciones están en p.userData.joints.
//  Para el texto de la espalda carga la fuente "Shrikhand" antes de crearlo.
// =====================================================================
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';

export const COLORS_593 = {
  navy: '#1d2140',
  navyDark: '#14172e',
  teal: '#36a996',
  tealDark: '#2a8b7b',
  skin: '#cf9e80',
  skinDark: '#b98468',
  lip: '#b27566',
  hair: '#161110',
  shoe: '#1b1b1f',
  rubber: '#efece3',
  gold: '#e9a83b',
  blue: '#2c6fc9',
  metal: '#b9bcc2',
};

// ---------------------------------------------------------------------
//  utilidades
// ---------------------------------------------------------------------
const smooth = (a, b, x) => {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
};
function seeded(seed) {
  let s = seed >>> 0;
  return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296);
}
function mk(geo, mat, name, parent) {
  const m = new THREE.Mesh(geo, mat);
  m.castShadow = true;
  m.receiveShadow = true;
  if (name) m.name = name;
  if (parent) parent.add(m);
  return m;
}
function pivot(name, parent, x = 0, y = 0, z = 0) {
  const g = new THREE.Group();
  g.name = name;
  g.position.set(x, y, z);
  if (parent) parent.add(g);
  return g;
}
// tubo entre dos puntos (para cordones, costuras)
function tube(a, b, r, mat, name, parent, seg = 6) {
  const d = new THREE.Vector3().subVectors(b, a);
  const m = mk(new THREE.CylinderGeometry(r, r, d.length(), seg), mat, name, parent);
  m.position.copy(a).addScaledVector(d, 0.5);
  m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize());
  return m;
}

// ---------------------------------------------------------------------
//  texturas
// ---------------------------------------------------------------------
function canvasTex(w, h, draw, repeat) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  if (repeat) {
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(repeat[0], repeat[1]);
  }
  return t;
}
// tela de polar (ruido suave)
function fleeceTex(base, seed) {
  const rnd = seeded(seed);
  return canvasTex(256, 256, (ctx, w, h) => {
    ctx.fillStyle = base; ctx.fillRect(0, 0, w, h);
    for (let i = 0; i < 9000; i++) {
      const v = rnd();
      ctx.fillStyle = v > 0.5 ? 'rgba(255,255,255,0.035)' : 'rgba(0,0,0,0.06)';
      ctx.fillRect(rnd() * w, rnd() * h, 1 + rnd() * 2, 1 + rnd() * 2);
    }
  }, [4, 4]);
}
function ribTex(base, line) {
  return canvasTex(64, 64, (ctx) => {
    ctx.fillStyle = base; ctx.fillRect(0, 0, 64, 64);
    ctx.fillStyle = line;
    for (let x = 0; x < 64; x += 6) ctx.fillRect(x, 0, 2, 64);
  }, [16, 1]);
}
function canvasTexCloth(base) {
  // lona de zapatilla (trama)
  return canvasTex(128, 128, (ctx, w, h) => {
    ctx.fillStyle = base; ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = 'rgba(255,255,255,0.05)';
    for (let i = 0; i < w; i += 3) { ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, h); ctx.stroke(); }
    ctx.strokeStyle = 'rgba(0,0,0,0.25)';
    for (let i = 0; i < h; i += 3) { ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(w, i); ctx.stroke(); }
  }, [3, 3]);
}
function drawInfinity(ctx, cx, cy, w, h, lw, C) {
  const grad = ctx.createLinearGradient(cx - w / 2, cy, cx + w / 2, cy);
  grad.addColorStop(0, C.gold); grad.addColorStop(0.5, C.teal); grad.addColorStop(1, C.blue);
  ctx.strokeStyle = grad; ctx.lineWidth = lw; ctx.lineCap = 'round';
  ctx.beginPath();
  for (let i = 0; i <= 240; i++) {
    const t = (i / 240) * Math.PI * 2;
    const d = 1 + Math.sin(t) ** 2;
    const x = cx + (w / 2) * Math.cos(t) / d, y = cy + h * Math.sin(t) * Math.cos(t) / d;
    i ? ctx.lineTo(x, y) : ctx.moveTo(x, y);
  }
  ctx.stroke();
}
const BACK_FONT = 'Shrikhand, "Cooper Black", Georgia, serif';

// ---------------------------------------------------------------------
//  perfil de la chaqueta (radio según altura) y deformación compartida
// ---------------------------------------------------------------------
const JACKET_PROFILE = [
  [0.000, 0.168], [0.03, 0.172], [0.12, 0.170], [0.22, 0.172], [0.30, 0.178],
  [0.38, 0.176], [0.43, 0.165], [0.47, 0.140], [0.50, 0.105], [0.515, 0.075], [0.52, 0.066],
];
const JACKET_H = 0.52;
const jacketCurve = new THREE.SplineCurve(JACKET_PROFILE.map(([y, r]) => new THREE.Vector2(r, y)));
const jacketDense = jacketCurve.getPoints(80);
function jacketR(y) {
  for (let i = 1; i < jacketDense.length; i++) {
    const a = jacketDense[i - 1], b = jacketDense[i];
    if (y <= b.y) return a.x + ((b.x - a.x) * (y - a.y)) / Math.max(1e-6, b.y - a.y);
  }
  return jacketDense[jacketDense.length - 1].x;
}
function deformJacket(geo, offset = 0) {
  const p = geo.attributes.position;
  for (let i = 0; i < p.count; i++) {
    let x = p.getX(i), y = p.getY(i), z = p.getZ(i);
    const k = smooth(0.28, 0.46, y);
    x *= 1 + 0.2 * k;
    z *= 0.64 * (1 - 0.1 * k);
    if (z > 0) z *= 1.04; // pecho un poco más adelante
    p.setXYZ(i, x, y, z);
  }
  geo.computeVertexNormals();
  return geo;
}
function jacketPatch(y0, y1, phiStart, phiLen, off, segs = 24) {
  const pts = [];
  const N = 10;
  for (let i = 0; i <= N; i++) {
    const y = y0 + ((y1 - y0) * i) / N;
    pts.push(new THREE.Vector2(jacketR(y) + off, y));
  }
  return deformJacket(new THREE.LatheGeometry(pts, segs, phiStart, phiLen));
}

// ---------------------------------------------------------------------
//  PERSONAJE
// ---------------------------------------------------------------------
export function createEsteban593(options = {}) {
  const C = { ...COLORS_593, ...(options.colors || {}) };
  const std = (color, o = {}) => new THREE.MeshStandardMaterial({ color, roughness: 0.8, ...o });
  const M = {
    navy: std('#ffffff', { map: fleeceTex(C.navy, 11), roughness: 0.95 }),
    navyRib: std('#ffffff', { map: ribTex(C.navy, '#151831'), roughness: 0.95 }),
    teal: std('#ffffff', { map: fleeceTex(C.teal, 12), roughness: 0.95 }),
    tealDark: std(C.tealDark, { roughness: 0.95 }),
    pants: std('#ffffff', { map: fleeceTex(C.navy, 13), roughness: 0.95 }),
    skin: std(C.skin, { roughness: 0.55 }),
    skinDark: std(C.skinDark, { roughness: 0.6 }),
    lip: std(C.lip, { roughness: 0.45 }),
    hair: std(C.hair, { roughness: 0.68, metalness: 0.0 }),
    brow: std('#1d1512', { roughness: 0.7 }),
    sclera: std('#f4f1ea', { roughness: 0.25 }),
    iris: std('#3b2519', { roughness: 0.2 }),
    pupil: std('#090706', { roughness: 0.1 }),
    canvas: std('#ffffff', { map: canvasTexCloth(C.shoe), roughness: 0.9 }),
    rubber: std(C.rubber, { roughness: 0.55 }),
    shoeLine: std(C.shoe, { roughness: 0.6 }),
    lace: std('#f4f2ec', { roughness: 0.7 }),
    metal: std(C.metal, { roughness: 0.3, metalness: 0.85 }),
    zip: std('#262838', { roughness: 0.35, metalness: 0.6 }),
    gold: std(C.gold, { roughness: 0.6 }),
    mouth: std('#4a2020', { roughness: 0.7 }),
    nail: std('#d9b2a0', { roughness: 0.35 }),
  };

  const root = new THREE.Group();
  root.name = 'EstebanBenavides_593';
  const J = {};

  // ================================================= PELVIS
  const PELVIS_Y = 0.94;
  const pelvis = pivot('pelvis', root, 0, PELVIS_Y, 0);
  J.pelvis = pelvis;
  const hips = mk(new THREE.SphereGeometry(1, 32, 20), M.pants, 'cadera', pelvis);
  hips.scale.set(0.15, 0.08, 0.105); hips.position.y = 0.01;

  // ================================================= PIERNAS
  const THIGH = 0.41, SHIN = 0.40;
  function leg(side) {
    const s = side === 'L' ? 1 : -1;
    const outer = s > 0 ? Math.PI / 2 : -Math.PI / 2;
    const hip = pivot('cadera' + side, pelvis, 0.088 * s, -0.035, 0);
    J['hip' + side] = hip;
    mk(new THREE.SphereGeometry(0.08, 24, 16), M.pants, 'muslo_raiz' + side, hip);
    // muslo con forma (lathe)
    const thighPts = [[0.074, 0], [0.079, -0.06], [0.075, -0.2], [0.066, -0.34], [0.061, -0.42]].map(([r, y]) => new THREE.Vector2(r, y));
    const thighGeo = new THREE.LatheGeometry(thighPts.reverse(), 28);
    mk(thighGeo, M.pants, 'muslo' + side, hip);
    // franja turquesa
    const stripeT = [[0.0755, -0.02], [0.0805, -0.06], [0.0765, -0.2], [0.0675, -0.34], [0.0625, -0.415]].map(([r, y]) => new THREE.Vector2(r, y)).reverse();
    mk(new THREE.LatheGeometry(stripeT, 8, outer - 0.2, 0.4), M.teal, 'franja_muslo' + side, hip).material.side = THREE.DoubleSide;
    // costura delantera
    tube(new THREE.Vector3(0, -0.04, 0.078), new THREE.Vector3(0, -0.4, 0.06), 0.0018, M.navyRib, 'costura' + side, hip);
    if (s > 0) {
      const tag = mk(new RoundedBoxGeometry(0.022, 0.018, 0.004, 1, 0.002), M.gold, 'etiqueta_pantalon', hip);
      tag.position.set(-0.03, -0.06, 0.072); tag.rotation.y = -0.35;
    }
    // rodilla
    const knee = pivot('rodilla' + side, hip, 0, -THIGH, 0);
    J['knee' + side] = knee;
    mk(new THREE.SphereGeometry(0.0625, 22, 14), M.pants, 'rodilla_m' + side, knee);
    const shinPts = [[0.061, 0.01], [0.06, -0.08], [0.056, -0.22], [0.05, -0.33], [0.047, -0.37]].map(([r, y]) => new THREE.Vector2(r, y)).reverse();
    mk(new THREE.LatheGeometry(shinPts, 26), M.pants, 'pierna' + side, knee);
    const stripeS = [[0.0625, 0.0], [0.0615, -0.08], [0.0575, -0.22], [0.0515, -0.33], [0.0485, -0.365]].map(([r, y]) => new THREE.Vector2(r, y)).reverse();
    mk(new THREE.LatheGeometry(stripeS, 8, outer - 0.21, 0.42), M.teal, 'franja_pierna' + side, knee).material.side = THREE.DoubleSide;
    // arrugas del jogger sobre el puño
    for (let i = 0; i < 3; i++) {
      const w = mk(new THREE.TorusGeometry(0.048 - i * 0.0005, 0.005, 6, 24), M.pants, `arruga${side}${i}`, knee);
      w.rotation.x = Math.PI / 2 + (i % 2 ? 0.12 : -0.1); w.position.y = -0.3 + i * 0.022;
    }
    // puño elástico
    mk(new THREE.CylinderGeometry(0.045, 0.043, 0.04, 24), M.navyRib, 'puno_pantalon' + side, knee).position.y = -0.375;
    // tobillo
    const ankle = pivot('tobillo' + side, knee, 0, -SHIN, 0);
    J['ankle' + side] = ankle;
    shoe(ankle, side);
  }

  // ------------------------------------------------- zapatilla de lona caña alta
  // perfil lateral (z = adelante, y = arriba) extruido a lo ancho con bisel
  const SHOE_PROFILE = [
    [-0.098, -0.052], [-0.102, 0.0], [-0.094, 0.062], [-0.07, 0.072], [-0.01, 0.07],
    [0.03, 0.035], [0.075, 0.006], [0.105, -0.01], [0.13, -0.02], [0.146, -0.03], [0.152, -0.042], [0.15, -0.052],
  ];
  const TOE_PROFILE = [
    [0.088, -0.054], [0.088, -0.038], [0.105, -0.029], [0.128, -0.025], [0.146, -0.032], [0.155, -0.043], [0.153, -0.054],
  ];
  const INSTEP_A = new THREE.Vector2(0.0, 0.068), INSTEP_B = new THREE.Vector2(0.088, 0.0);
  // medio ancho del pie visto desde arriba (z = adelante)
  const footHalfW = (z) => {
    if (z > 0.1) return 0.047 * Math.sqrt(Math.max(0, 1 - ((z - 0.1) / 0.066) ** 2));
    if (z > 0.03) return 0.047;
    if (z > -0.06) return 0.04 + 0.007 * smooth(-0.06, 0.03, z);
    return 0.04 - 0.008 * smooth(-0.06, -0.13, z);
  };
  function soleGeo(margin, h, bev = 0.006) {
    const sh = new THREE.Shape();
    const zs = [];
    for (let z = -0.128; z <= 0.166; z += 0.006) zs.push(Math.min(z, 0.166));
    zs.push(0.166);
    zs.forEach((z, i) => { const w = footHalfW(Math.min(z, 0.1659)) + margin; i ? sh.lineTo(w, z) : sh.moveTo(w, z); });
    [...zs].reverse().forEach((z) => sh.lineTo(-footHalfW(Math.min(z, 0.1659)) - margin, z));
    // la forma está en (x, z); se extruye hacia arriba
    const g = new THREE.ExtrudeGeometry(sh, { depth: h, bevelEnabled: true, bevelThickness: bev, bevelSize: bev * 0.85, bevelSegments: 3, curveSegments: 6 });
    g.rotateX(Math.PI / 2); // la forma queda en el plano XZ y se extruye hacia abajo
    g.computeVertexNormals();
    return g;
  }
  function shoeUpperGeo(width, inset = 0, profile = SHOE_PROFILE) {
    const sh = new THREE.Shape();
    // perfil suavizado y con más puntos (para que el estrechamiento sea suave)
    const curve = new THREE.SplineCurve(profile.map(([z, y]) => new THREE.Vector2(z, y)));
    curve.getPoints(56).forEach((v, i) => (i ? sh.lineTo(v.x, v.y) : sh.moveTo(v.x, v.y)));
    sh.closePath();
    const bevel = 0.012 - inset;
    const g = new THREE.ExtrudeGeometry(sh, { depth: width - bevel * 2, bevelEnabled: true, bevelThickness: bevel, bevelSize: bevel * 0.9, bevelSegments: 5, curveSegments: 8 });
    g.translate(0, 0, -(width - bevel * 2) / 2);
    g.rotateY(-Math.PI / 2); // x de la forma -> z del mundo
    // redondear la punta (estrechar adelante)
    const p = g.attributes.position;
    for (let i = 0; i < p.count; i++) {
      const z = p.getZ(i);
      const k = Math.max(0.3, footHalfW(Math.min(z, 0.165)) / 0.047);
      p.setX(i, p.getX(i) * k);
    }
    g.computeVertexNormals();
    return g;
  }
  function shoe(parent, side) {
    const s = side === 'L' ? 1 : -1;
    const g = pivot('zapatilla' + side, parent);
    // la lona
    const upper = mk(shoeUpperGeo(0.088), M.canvas, 'lona' + side, g);
    upper.position.y = -0.024;
    // suela blanca + línea negra (foxing)
    mk(soleGeo(0.003, 0.02), M.rubber, 'suela' + side, g).position.y = -0.064;
    mk(soleGeo(0.0072, 0.002, 0.001), M.shoeLine, 'linea_suela' + side, g).position.y = -0.07;
    // puntera de goma
    const cap = mk(shoeUpperGeo(0.092, -0.002, TOE_PROFILE), M.rubber, 'puntera' + side, g);
    cap.position.y = -0.024;
    // tira trasera de goma y etiqueta del talón
    mk(new RoundedBoxGeometry(0.03, 0.05, 0.006, 2, 0.002), M.rubber, 'talon' + side, g).position.set(0, -0.045, -0.123);
    mk(new RoundedBoxGeometry(0.02, 0.012, 0.003, 1, 0.001), M.shoeLine, 'etiqueta_talon' + side, g).position.set(0, -0.042, -0.1265);
    // borde de la caña
    const rimC = mk(new THREE.TorusGeometry(0.04, 0.0045, 6, 24), M.shoeLine, 'borde_cana' + side, g);
    rimC.rotation.x = Math.PI / 2; rimC.scale.set(1, 1.35, 1); rimC.position.set(0, 0.046, -0.05);
    // lengüeta
    const dir = new THREE.Vector2().subVectors(INSTEP_B, INSTEP_A);
    const ang = Math.atan2(dir.y, dir.x);
    const tongue = mk(new RoundedBoxGeometry(0.036, 0.005, dir.length() + 0.03, 2, 0.002), M.canvas, 'lengueta' + side, g);
    tongue.rotation.x = -ang; tongue.position.set(0, (INSTEP_A.y + INSTEP_B.y) / 2 - 0.02, (INSTEP_A.x + INSTEP_B.x) / 2);
    // ojales y cordones cruzados sobre el empeine
    const nrm = new THREE.Vector3(0, dir.x, -dir.y).normalize(); // normal hacia arriba/adelante
    const N = 7, eye = [];
    for (let i = 0; i < N; i++) {
      const t = i / (N - 1);
      const zz = INSTEP_B.x + (INSTEP_A.x - INSTEP_B.x) * t;
      const yy = INSTEP_B.y + (INSTEP_A.y - INSTEP_B.y) * t - 0.024;
      for (const e of [1, -1]) {
        const p = new THREE.Vector3(0.024 * e * (1 - 0.15 * (1 - t)), yy, zz).addScaledVector(nrm, 0.002);
        const ring = mk(new THREE.TorusGeometry(0.0042, 0.0014, 5, 10), M.metal, 'ojal', g);
        ring.position.copy(p);
        ring.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), nrm);
        eye.push(p);
      }
    }
    const up = nrm.clone().multiplyScalar(0.0035);
    for (let i = 0; i < N - 1; i++) {
      const a = eye[i * 2], b = eye[i * 2 + 1], a2 = eye[i * 2 + 2], b2 = eye[i * 2 + 3];
      tube(a.clone().add(up), b2.clone().add(up), 0.0021, M.lace, 'cordon', g);
      tube(b.clone().add(up), a2.clone().add(up), 0.0021, M.lace, 'cordon', g);
    }
    // lazo
    const top = eye[(N - 1) * 2].clone().add(eye[(N - 1) * 2 + 1]).multiplyScalar(0.5).addScaledVector(nrm, 0.006);
    for (const e of [1, -1]) {
      const loop = mk(new THREE.TorusGeometry(0.011, 0.0019, 5, 14), M.lace, 'lazo', g);
      loop.position.copy(top).add(new THREE.Vector3(0.011 * e, 0.0, 0.004)); loop.rotation.set(0.9, 0.5 * e, 0.3 * e);
      tube(top, top.clone().add(new THREE.Vector3(0.006 * e, -0.03, 0.012)), 0.0018, M.lace, 'punta_cordon', g);
    }
    // parche redondo del tobillo (lado interno)
    const patch = mk(new THREE.CylinderGeometry(0.018, 0.018, 0.003, 24), M.rubber, 'parche' + side, g);
    patch.rotation.z = Math.PI / 2; patch.position.set(-0.0455 * s, 0.01, -0.055);
  }
  leg('L');
  leg('R');

  // ================================================= TORSO / CHAQUETA
  const torso = pivot('torso', pelvis, 0, 0.02, 0);
  J.torso = torso;
  const chest = pivot('pecho', torso, 0, 0, 0); // segunda vértebra para giros
  J.chest = chest;
  const jacketGeo = deformJacket(new THREE.LatheGeometry(jacketDense, 64));
  const jacket = mk(jacketGeo, M.navy, 'chaqueta', chest);
  jacket.material.side = THREE.DoubleSide;
  // basta acanalada
  mk(jacketPatch(-0.04, 0.012, 0, Math.PI * 2, 0.004, 64), M.navyRib, 'basta', chest);
  // cuello alto acanalado
  const neckBand = mk(new THREE.CylinderGeometry(0.07, 0.08, 0.04, 32, 1, true), M.navyRib, 'cuello_alto', chest);
  neckBand.material = M.navyRib.clone(); neckBand.material.side = THREE.DoubleSide;
  neckBand.position.y = JACKET_H + 0.005; neckBand.scale.z = 0.88;
  const rim = mk(new THREE.TorusGeometry(0.07, 0.005, 8, 32), M.navyRib, 'cuello_borde', chest);
  rim.rotation.x = Math.PI / 2; rim.position.y = JACKET_H + 0.025; rim.scale.y = 0.88;
  // cierre con dientes
  const zipGroup = pivot('cierre', chest);
  const frontZ = (y) => jacketR(y) * 0.64 * (1 - 0.1 * smooth(0.28, 0.46, y)) * 1.04;
  for (let y = -0.03; y < 0.415; y += 0.008) {
    const tooth = mk(new THREE.BoxGeometry(0.009, 0.004, 0.004), M.zip, 'diente', zipGroup);
    tooth.position.set(0, y, frontZ(y) + 0.002);
    tooth.castShadow = false;
  }
  const puller = mk(new RoundedBoxGeometry(0.012, 0.03, 0.004, 1, 0.002), M.zip, 'jalador', zipGroup);
  puller.position.set(0, 0.39, frontZ(0.4) + 0.008); puller.rotation.x = -0.15;
  // bolsillos con ribete turquesa
  for (const s of [1, -1]) {
    const pk = mk(jacketPatch(0.03, 0.13, s > 0 ? 0.62 : -0.62 - 0.07, 0.07, 0.003, 3), M.teal, 'bolsillo' + (s > 0 ? 'L' : 'R'), chest);
    pk.material = M.teal;
  }
  // etiqueta amarilla en la basta
  mk(jacketPatch(0.04, 0.058, 0.32, 0.12, 0.004, 4), M.gold, 'etiqueta', chest);
  // logo del pecho (lado izquierdo del personaje)
  const logoTex = canvasTex(512, 320, (ctx) => {
    ctx.fillStyle = '#f3f3f3';
    ctx.font = '600 62px "Segoe UI", Helvetica, Arial, sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('Eight Academy', 256, 70);
    drawInfinity(ctx, 256, 205, 220, 145, 28, C);
  });
  const logo = mk(jacketPatch(0.33, 0.395, 0.3, 0.58, 0.0035, 16),
    new THREE.MeshStandardMaterial({ map: logoTex, transparent: true, roughness: 0.85, depthWrite: false, side: THREE.DoubleSide }), 'logo_pecho', chest);
  logo.castShadow = false;
  // estampado de la espalda
  const backTex = canvasTex(1024, 640, (ctx) => {
    ctx.textBaseline = 'alphabetic';
    ctx.fillStyle = C.gold; ctx.font = `150px ${BACK_FONT}`;
    ctx.fillText('We', 160, 175);
    ctx.fillText('are the', 160, 360);
    ctx.fillStyle = C.teal; ctx.font = `italic 165px ${BACK_FONT}`;
    ctx.fillText('change', 160, 555);
  });
  const back = mk(jacketPatch(0.2, 0.37, Math.PI - 0.85, 1.7, 0.0035, 28),
    new THREE.MeshStandardMaterial({ map: backTex, transparent: true, roughness: 0.85, depthWrite: false, side: THREE.DoubleSide }), 'estampado_espalda', chest);
  back.castShadow = false;
  // ================================================= BRAZOS
  const UPPER = 0.29, FORE = 0.255;
  function arm(side) {
    const s = side === 'L' ? 1 : -1;
    const sh = pivot('hombro' + side, chest, 0.185 * s, 0.415, -0.005);
    J['shoulder' + side] = sh;
    const cap = mk(new THREE.SphereGeometry(0.062, 24, 16), M.teal, 'hombro_m' + side, sh);
    cap.scale.set(1, 0.95, 0.95);
    const upPts = [[0.058, 0.01], [0.06, -0.06], [0.055, -0.18], [0.05, -0.29]].map(([r, y]) => new THREE.Vector2(r, y)).reverse();
    mk(new THREE.LatheGeometry(upPts, 24), M.teal, 'brazo' + side, sh);
    const el = pivot('codo' + side, sh, 0, -UPPER, 0);
    J['elbow' + side] = el;
    mk(new THREE.SphereGeometry(0.05, 20, 14), M.teal, 'codo_m' + side, el);
    const forePts = [[0.05, 0.005], [0.049, -0.08], [0.045, -0.17], [0.042, -0.2]].map(([r, y]) => new THREE.Vector2(r, y)).reverse();
    mk(new THREE.LatheGeometry(forePts, 24), M.teal, 'antebrazo' + side, el);
    // pliegues de la manga
    for (let i = 0; i < 3; i++) {
      const w = mk(new THREE.TorusGeometry(0.045 - i * 0.001, 0.003, 6, 22), M.teal, `pliegue${side}${i}`, el);
      w.rotation.x = Math.PI / 2 + (i % 2 ? 0.15 : -0.12); w.position.y = -0.14 - i * 0.022;
    }
    // puño acanalado que cubre parte de la mano
    mk(new THREE.CylinderGeometry(0.041, 0.039, 0.06, 22), M.navyRib, 'puno' + side, el).position.y = -0.225;
    // mano
    const wrist = pivot('muneca' + side, el, 0, -FORE, 0);
    J['wrist' + side] = wrist;
    hand(wrist, side);
  }

  // ------------------------------------------------- mano con dedos articulados
  const fingers = { L: [], R: [] };
  function hand(parent, side) {
    const s = side === 'L' ? 1 : -1;
    const palm = mk(new RoundedBoxGeometry(0.072, 0.082, 0.026, 3, 0.011), M.skin, 'palma' + side, parent);
    palm.position.y = -0.045;
    // parte del puño de la chaqueta sobre el dorso (agujero para el pulgar)
    const thumbHole = mk(new RoundedBoxGeometry(0.076, 0.03, 0.03, 2, 0.01), M.navyRib, 'puno_dorso' + side, parent);
    thumbHole.position.set(0, -0.012, 0);
    const xs = [-0.026, -0.009, 0.009, 0.026];
    const lens = [[0.03, 0.024, 0.02], [0.034, 0.027, 0.021], [0.033, 0.026, 0.021], [0.026, 0.021, 0.018]];
    xs.forEach((x, i) => {
      let par = pivot(`dedo${side}${i}`, parent, -x * s, -0.084, 0);
      const chain = [];
      lens[i].forEach((L, k) => {
        const r = 0.0085 - k * 0.0008 - (i === 3 ? 0.001 : 0);
        const seg = mk(new THREE.CapsuleGeometry(r, L - r, 4, 8), M.skin, `falange${side}${i}${k}`, par);
        seg.position.y = -L / 2;
        if (k === 2) {
          const nail = mk(new THREE.SphereGeometry(r * 0.9, 8, 6), M.nail, 'una', par);
          nail.scale.set(0.9, 1.2, 0.35); nail.position.set(0, -L * 0.6, -r * 0.75);
        }
        chain.push(par);
        par = pivot(`nudillo${side}${i}${k}`, par, 0, -L, 0);
      });
      fingers[side].push(chain);
    });
    // pulgar (apunta hacia adelante cuando el brazo cuelga)
    const tb = pivot('pulgar' + side, parent, 0.034 * s, -0.03, 0.006);
    tb.rotation.set(0.2, 0, 0.55 * s);
    const t1 = mk(new THREE.CapsuleGeometry(0.01, 0.026, 4, 8), M.skin, 'pulgar1' + side, tb);
    t1.position.y = -0.018;
    const tb2 = pivot('pulgar_punta' + side, tb, 0, -0.036, 0);
    const t2 = mk(new THREE.CapsuleGeometry(0.009, 0.02, 4, 8), M.skin, 'pulgar2' + side, tb2);
    t2.position.y = -0.013;
    fingers[side].thumb = [tb, tb2];
  }
  // la palma mira hacia +Z local; el pulgar está del lado +X local en la izquierda
  function setFist(side, amount) {
    for (const chain of fingers[side]) {
      chain.forEach((j, k) => (j.rotation.x = -amount * (k === 0 ? 1.45 : 1.6) - 0.12 * (k + 1) * (1 - amount)));
    }
    const s = side === 'L' ? 1 : -1;
    const [tb, tb2] = fingers[side].thumb;
    tb.rotation.set(0.2 - amount * 0.75, amount * 0.25 * s, (0.55 - amount * 1.05) * s);
    tb2.rotation.set(-amount * 0.5, 0, -amount * 0.9 * s);
  }
  arm('L');
  arm('R');

  // ================================================= CUELLO Y CABEZA
  const neck = pivot('cuello', chest, 0, JACKET_H - 0.01, 0.005);
  J.neck = neck;
  mk(new THREE.CylinderGeometry(0.046, 0.052, 0.12, 20), M.skin, 'cuello_piel', neck).position.y = 0.05;
  const head = pivot('cabeza', neck, 0, 0.152, 0.008);
  J.head = head;

  // cráneo + cara: esfera deformada
  const headGeo = new THREE.SphereGeometry(1, 64, 48);
  {
    const p = headGeo.attributes.position;
    const v = new THREE.Vector3();
    for (let i = 0; i < p.count; i++) {
      v.fromBufferAttribute(p, i);
      let { x, y, z } = v;
      // mandíbula más angosta y mentón
      const low = Math.max(0, -y);
      x *= 1 - 0.17 * Math.pow(low, 1.6);
      if (z > 0) z *= 1 + 0.06 * low;
      // nuca un poco más llena
      if (z < 0 && y > -0.4) z *= 1.07;
      // cara un poco plana
      if (z > 0.75) z = 0.75 + (z - 0.75) * 0.55;
      // cuencas de los ojos
      for (const s of [1, -1]) {
        const d2 = (x - 0.38 * s) ** 2 + (y - 0.08) ** 2 * 1.6 + (z - 0.86) ** 2;
        const k = Math.exp(-d2 / 0.018);
        z -= 0.07 * k;
      }
      // tabique de la nariz
      {
        const wy = smooth(-0.32, -0.2, y) * (1 - smooth(0.0, 0.12, y));
        z += 0.15 * Math.exp(-(x * x) / 0.005) * wy * (z > 0 ? 1 : 0);
      }
      // pómulos
      for (const s of [1, -1]) {
        const d2 = (x - 0.55 * s) ** 2 + (y + 0.12) ** 2 + (z - 0.72) ** 2;
        const k = Math.exp(-d2 / 0.03);
        x += 0.03 * s * k; z += 0.025 * k;
      }
      p.setXYZ(i, x * 0.079, y * 0.112, z * 0.097);
    }
    headGeo.computeVertexNormals();
  }
  mk(headGeo, M.skin, 'cabeza_piel', head);

  // orejas
  for (const s of [1, -1]) {
    const ear = pivot('oreja' + (s > 0 ? 'L' : 'R'), head, 0.077 * s, -0.005, -0.012);
    ear.rotation.y = 0.25 * s;
    const outer = mk(new THREE.SphereGeometry(1, 16, 12), M.skin, 'oreja_ext', ear);
    outer.scale.set(0.009, 0.029, 0.018);
    const inner = mk(new THREE.SphereGeometry(1, 12, 8), M.skinDark, 'oreja_int', ear);
    inner.scale.set(0.005, 0.018, 0.01); inner.position.set(0.005 * s, 0.002, 0.002);
    const lobe = mk(new THREE.SphereGeometry(0.007, 10, 8), M.skin, 'lobulo', ear);
    lobe.position.set(0, -0.024, 0.004);
  }

  // ojos con párpados
  const eyes = [];
  for (const s of [1, -1]) {
    const e = pivot('ojo' + (s > 0 ? 'L' : 'R'), head, 0.031 * s, 0.006, 0.0705);
    e.scale.set(1, 0.9, 0.9);
    const ball = mk(new THREE.SphereGeometry(0.0118, 20, 16), M.sclera, 'globo', e);
    
    const iris = mk(new THREE.SphereGeometry(0.0065, 16, 12), M.iris, 'iris', e);
    iris.scale.set(1, 1, 0.4); iris.position.set(-0.0008 * s, -0.0005, 0.0098);
    const pupil = mk(new THREE.SphereGeometry(0.0032, 10, 8), M.pupil, 'pupila', e);
    pupil.scale.set(1, 1, 0.4); pupil.position.set(-0.0008 * s, -0.0005, 0.0112);
    const shine = mk(new THREE.SphereGeometry(0.0013, 6, 5), M.sclera, 'brillo', e);
    shine.position.set(0.002, 0.002, 0.0118);
    // párpado superior (mirada tranquila, un poco caída)
    const lidU = mk(new THREE.SphereGeometry(0.0124, 20, 10, 0, Math.PI * 2, 0, Math.PI * 0.45), M.skinDark, 'parpado_sup', e);
    lidU.rotation.x = 0.35;
    const lidL = mk(new THREE.SphereGeometry(0.0122, 20, 8, 0, Math.PI * 2, Math.PI * 0.7, Math.PI * 0.3), M.skin, 'parpado_inf', e);
    lidL.rotation.x = -0.1;
    // línea de pestañas
    const lash = mk(new THREE.TorusGeometry(0.0118, 0.0011, 4, 16, Math.PI * 0.9), M.pupil, 'pestanas', e);
    lash.position.set(0, 0.0005, 0.001); lash.rotation.set(-0.35, 0, Math.PI * 0.05); lash.scale.set(1, 0.75, 1);
    eyes.push({ e, lidU });
    // ceja hecha de pelitos
    const brow = pivot('ceja' + (s > 0 ? 'L' : 'R'), head, 0.033 * s, 0.027, 0.083);
    brow.rotation.set(-0.25, 0.32 * s, 0.03 * s);
    for (let i = 0; i < 9; i++) {
      const t = i / 8;
      const h = mk(new THREE.CapsuleGeometry(0.0022 - t * 0.0008, 0.008, 3, 5), M.brow, 'pelo_ceja', brow);
      h.position.set((-0.014 + t * 0.028) * s, 0.002 * Math.sin(t * Math.PI), 0);
      h.rotation.z = (Math.PI / 2 - 0.5 + (i % 2) * 0.15) * s;
    }
  }
  // nariz
  const nose = pivot('nariz', head, 0, -0.012, 0.088);
  const tip = mk(new THREE.SphereGeometry(0.0095, 16, 12), M.skin, 'punta_nariz', nose);
  tip.scale.set(1.08, 0.85, 0.85); tip.position.set(0, -0.012, 0.0075);
  for (const s of [1, -1]) {
    const al = mk(new THREE.SphereGeometry(0.005, 12, 10), M.skin, 'ala', nose);
    al.scale.set(1, 0.9, 0.8); al.position.set(0.0088 * s, -0.0155, -0.0005);
    const nostril = mk(new THREE.SphereGeometry(0.003, 8, 6), M.mouth, 'fosa', nose);
    nostril.scale.set(1.2, 0.55, 1); nostril.position.set(0.0048 * s, -0.0195, 0.0035);
  }
  // boca (labios)
  const mouth = pivot('boca', head, 0, -0.052, 0.08);
  J.mouth = mouth;
  const upLip = mk(new THREE.CapsuleGeometry(0.003, 0.028, 4, 10), M.lip, 'labio_sup', mouth);
  upLip.rotation.z = Math.PI / 2; upLip.position.set(0, 0.003, 0); upLip.scale.set(1, 1, 0.6);
  const loLip = mk(new THREE.CapsuleGeometry(0.0036, 0.022, 4, 10), M.lip, 'labio_inf', mouth);
  loLip.rotation.z = Math.PI / 2; loLip.position.set(0, -0.0042, -0.0015); loLip.scale.set(1, 1, 0.6);
  mk(new THREE.BoxGeometry(0.028, 0.001, 0.002), M.mouth, 'comisura', mouth).position.set(0, -0.0006, 0.0005);

  // ------------------------------------------------- PELO
  const HR = { x: 0.083, y: 0.117, z: 0.103 };
  const hairG = pivot('pelo', head, 0, 0.004, -0.004);
  const onHead = (polar, az, k = 1) =>
    new THREE.Vector3(HR.x * k * Math.sin(polar) * Math.sin(az), HR.y * k * Math.cos(polar), HR.z * k * Math.sin(polar) * Math.cos(az));
  // base del pelo con línea de nacimiento: frente alta, nuca baja
  const hairline = (az) => {
    const f = Math.cos(az);
    return f > 0 ? 1.32 + (0.98 - 1.32) * Math.pow(f, 1.2) : 1.32 + (2.22 - 1.32) * Math.pow(-f, 0.8);
  };
  const capGeo = new THREE.SphereGeometry(1, 64, 40);
  {
    const p = capGeo.attributes.position;
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i), y = p.getY(i), z = p.getZ(i);
      const polar = Math.acos(Math.max(-1, Math.min(1, y)));
      const az = Math.atan2(x, z);
      const pl = Math.min(polar, hairline(az));
      p.setXYZ(i, HR.x * 0.995 * Math.sin(pl) * Math.sin(az), HR.y * 0.995 * Math.cos(pl), HR.z * 0.995 * Math.sin(pl) * Math.cos(az));
    }
    capGeo.computeVertexNormals();
  }
  const cap = mk(capGeo, M.hair.clone(), 'pelo_base', hairG);
  cap.material.roughness = 0.9;

  const rnd = seeded(593);
  const lockBase = (() => {
    const g = new THREE.SphereGeometry(1, 6, 6);
    const p = g.attributes.position;
    for (let i = 0; i < p.count; i++) {
      const t = (p.getY(i) + 1) / 2;
      const k = 1 - 0.82 * t * t;
      p.setX(i, p.getX(i) * k);
      p.setZ(i, p.getZ(i) * k);
    }
    g.computeVertexNormals();
    return g;
  })();
  const locks = [];
  const _m = new THREE.Matrix4();
  function lock(polar, az, len, wid, thick, sweep = 0, lift = 0.15, k = 1, curl = 0) {
    const P = onHead(polar, az, k);
    const n = new THREE.Vector3(P.x / (HR.x * HR.x), P.y / (HR.y * HR.y), P.z / (HR.z * HR.z)).normalize();
    const D = new THREE.Vector3(HR.x * Math.cos(polar) * Math.sin(az), -HR.y * Math.sin(polar), HR.z * Math.cos(polar) * Math.cos(az)).normalize();
    D.x += sweep;
    D.addScaledVector(n, -D.dot(n)).normalize().addScaledVector(n, lift).normalize();
    const Z = n.clone().addScaledVector(D, -n.dot(D)).normalize();
    const X = new THREE.Vector3().crossVectors(D, Z);
    _m.makeBasis(X, D, Z);
    const g = lockBase.clone();
    // ligera curvatura del mechón
    if (curl) {
      const p = g.attributes.position;
      for (let i = 0; i < p.count; i++) {
        const y = p.getY(i);
        p.setZ(i, p.getZ(i) + curl * (y + 1) * (y + 1) * 0.25);
      }
    }
    g.applyMatrix4(new THREE.Matrix4().makeScale(wid, len / 2, thick));
    g.applyMatrix4(_m);
    const pos = P.clone().addScaledVector(D, len * 0.38).addScaledVector(n, thick * 0.3);
    g.translate(pos.x, pos.y, pos.z);
    locks.push(g);
  }
  // capas desde la coronilla
  for (let layer = 0; layer < 2; layer++) {
    const kk = layer ? 1.04 : 1.005;
    for (let ring = 0; ring < 12; ring++) {
      const polar = 0.05 + ring * 0.16 + layer * 0.06;
      const count = ring === 0 ? 7 : 14 + ring * 4;
      for (let i = 0; i < count; i++) {
        const az = (i / count) * Math.PI * 2 + rnd() * 0.25 + ring * 0.37 + layer * 0.2;
        if (polar > hairline(az) - 0.12) continue;
        lock(polar, az, (0.05 + rnd() * 0.03) * (polar > 1.1 ? 0.75 : 1), 0.012 + rnd() * 0.007, 0.0065 + rnd() * 0.003,
          (rnd() - 0.5) * 0.45, 0.04 + rnd() * 0.12 + layer * 0.05, kk, (rnd() - 0.5) * 0.7);
      }
    }
  }
  // flequillo espeso sobre la frente, barrido hacia -X
  for (let i = 0; i < 22; i++) {
    const az = -0.95 + (i / 21) * 1.9 + (rnd() - 0.5) * 0.08;
    lock(0.5 + rnd() * 0.16, az, 0.065 + rnd() * 0.02, 0.014 + rnd() * 0.005, 0.0075,
      -0.3 - rnd() * 0.25, 0.04 + rnd() * 0.07, 1.06 + rnd() * 0.03, 0.4);
  }
  // segunda fila del flequillo, más baja: tapa la línea del pelo
  for (let i = 0; i < 18; i++) {
    const az = -0.85 + (i / 17) * 1.7 + (rnd() - 0.5) * 0.08;
    lock(0.74 + rnd() * 0.12, az, 0.048 + rnd() * 0.014, 0.014 + rnd() * 0.004, 0.007,
      -0.25 - rnd() * 0.2, 0.02 + rnd() * 0.04, 1.035, 0.3);
  }
  // patillas
  for (const s of [1, -1]) {
    lock(1.12, s * 1.42, 0.042, 0.016, 0.007, 0, 0.02, 1.02);
    lock(1.2, s * 1.68, 0.05, 0.018, 0.008, 0, 0.03, 1.02);
    lock(1.3, s * 1.95, 0.035, 0.016, 0.007, 0, 0.03, 1.02);
  }
  // nuca
  for (let i = 0; i < 16; i++) lock(2.02 + rnd() * 0.1, Math.PI + (i - 7.5) * 0.16, 0.042, 0.015, 0.007, 0, 0.03, 0.995);
  // rebeldes arriba
  for (let i = 0; i < 12; i++) lock(0.15 + rnd() * 0.6, rnd() * Math.PI * 2, 0.04, 0.013, 0.007, (rnd() - 0.5) * 0.7, 0.35 + rnd() * 0.3, 1.06, 0.5);
  mk(mergeGeometries(locks), M.hair, 'pelo_mechones', hairG);

  // =====================================================================
  //  ANIMACIONES PROCEDURALES
  // =====================================================================
  const JOINTS = ['torso', 'chest', 'neck', 'head', 'shoulderL', 'elbowL', 'wristL', 'shoulderR', 'elbowR', 'wristR',
    'hipL', 'kneeL', 'ankleL', 'hipR', 'kneeR', 'ankleR'];
  const REST = {
    shoulderL: [0.02, 0, 0.1], shoulderR: [0.02, 0, -0.1],
    elbowL: [-0.18, 0, 0], elbowR: [-0.18, 0, 0],
    wristL: [0, -1.35, 0], wristR: [0, 1.35, 0],
    hipL: [0, 0, 0.02], hipR: [0, 0, -0.02],
  };
  const pulse = (x, c, w) => Math.exp(-((x - c) ** 2) / (w * w));

  const ANIMS = {
    idle: { dur: 4, f(t) {
      const b = Math.sin(t * Math.PI * 2 / 4 * 2);
      const sway = Math.sin(t * Math.PI * 2 / 4);
      return {
        y: -0.004 + b * 0.002, px: sway * 0.012,
        torso: [0.01 + b * 0.01, 0, -sway * 0.02], chest: [b * 0.012, 0, 0],
        head: [0.02, Math.sin(t * Math.PI * 2 / 4) * 0.25 * pulse((t % 4) / 4, 0.5, 0.25), 0],
        hipL: [0, 0, 0.02 + sway * 0.02], hipR: [0, 0, -0.02 + sway * 0.02],
        kneeL: [0.03 + Math.max(0, -sway) * 0.06, 0, 0], kneeR: [0.03 + Math.max(0, sway) * 0.06, 0, 0],
        shoulderL: [0.02 + b * 0.015, 0, 0.1], shoulderR: [0.02 - b * 0.015, 0, -0.1],
        fist: 0.25,
      };
    } },
    walk: { dur: 1.05, f(t) {
      const ph = (t / 1.05) * Math.PI * 2;
      const s = Math.sin(ph), c = Math.cos(ph);
      return {
        y: (Math.abs(c) - 0.6) * 0.03,
        torso: [0.04, s * 0.08, 0], chest: [0, -s * 0.14, s * 0.02], head: [-0.03, s * 0.06, 0],
        hipL: [-s * 0.42, 0, 0.02], hipR: [s * 0.42, 0, -0.02],
        kneeL: [0.06 + Math.max(0, c) * 0.85, 0, 0], kneeR: [0.06 + Math.max(0, -c) * 0.85, 0, 0],
        ankleL: [-s * 0.15 - Math.max(0, -c) * 0.25 * (s < 0 ? 1 : 0), 0, 0], ankleR: [s * 0.15 - Math.max(0, c) * 0.25 * (s > 0 ? 1 : 0), 0, 0],
        shoulderL: [s * 0.38, 0, 0.1], shoulderR: [-s * 0.38, 0, -0.1],
        elbowL: [-0.25 - Math.max(0, -s) * 0.35, 0, 0], elbowR: [-0.25 - Math.max(0, s) * 0.35, 0, 0],
        fist: 0.35,
      };
    } },
    run: { dur: 0.68, f(t) {
      const ph = (t / 0.68) * Math.PI * 2;
      const s = Math.sin(ph), c = Math.cos(ph);
      return {
        y: Math.abs(c) * 0.06 - 0.05,
        torso: [0.22, s * 0.12, 0], chest: [0.04, -s * 0.22, 0], head: [-0.2, s * 0.08, 0],
        hipL: [-s * 0.8 - 0.1, 0, 0.03], hipR: [s * 0.8 - 0.1, 0, -0.03],
        kneeL: [0.25 + Math.max(0, c) * 1.55, 0, 0], kneeR: [0.25 + Math.max(0, -c) * 1.55, 0, 0],
        ankleL: [-s * 0.3, 0, 0], ankleR: [s * 0.3, 0, 0],
        shoulderL: [s * 0.85, 0, 0.12], shoulderR: [-s * 0.85, 0, -0.12],
        elbowL: [-1.45 - Math.max(0, -s) * 0.2, 0, 0], elbowR: [-1.45 - Math.max(0, s) * 0.2, 0, 0],
        wristL: [0, -1.1, 0], wristR: [0, 1.1, 0],
        fist: 0.9,
      };
    } },
    punch: { dur: 1.2, f(t) {
      const x = t / 1.2;
      const jab = pulse(x, 0.18, 0.08), cross = pulse(x, 0.6, 0.09);
      const bob = Math.sin(x * Math.PI * 4) * 0.01;
      return {
        y: -0.05 + bob, pz: 0,
        torso: [0.08, 0.35 - cross * 0.75 + jab * 0.15, 0], chest: [0.04, -0.1 - cross * 0.3 + jab * 0.2, 0], head: [0.05, -0.25 + cross * 0.4, 0],
        hipL: [-0.35, 0.15, 0.12], kneeL: [0.45, 0, 0], ankleL: [-0.1, 0, 0],
        hipR: [0.2, -0.2, -0.12], kneeR: [0.35, 0, 0], ankleR: [-0.15, 0, 0],
        // guardia + jab (izquierda) + directo (derecha)
        shoulderL: [-0.9 - jab * 0.62, 0, -0.25 + jab * 0.2], elbowL: [-1.95 + jab * 1.85, 0, 0], wristL: [0, -1.4 + jab * 0.2, 0],
        shoulderR: [-0.75 - cross * 0.8, 0, 0.3 - cross * 0.1], elbowR: [-2.05 + cross * 1.95, 0, 0], wristR: [0, 1.4 - cross * 0.2, 0],
        fist: 1,
      };
    } },
    drive: { dur: 3, f(t) {
      const w = Math.sin((t / 3) * Math.PI * 2);
      return {
        y: 0,
        torso: [-0.18, 0, 0], chest: [0.02, w * 0.03, 0], head: [0.14, w * 0.12, 0],
        hipL: [-1.42, 0, 0.1], kneeL: [1.3, 0, 0], ankleL: [-0.2, 0, 0],
        hipR: [-1.42, 0, -0.1], kneeR: [1.3, 0, 0], ankleR: [-0.25, 0, 0],
        shoulderL: [-0.95 + w * 0.08, 0, -0.08], elbowL: [-0.75, 0, 0.15], wristL: [0.1, -1.35, 0],
        shoulderR: [-0.95 - w * 0.08, 0, 0.08], elbowR: [-0.75, 0, -0.15], wristR: [0.1, 1.35, 0],
        fist: 0.75,
      };
    } },
  };

  let anim = 'idle', time = 0, blend = 1;
  const from = {};
  let fromY = 0, fromFist = 0.25;
  let lastFist = 0.25, lastY = 0;
  let blinkT = 2.5;

  function play(name) {
    if (!ANIMS[name] || name === anim) return;
    for (const n of JOINTS) from[n] = [J[n].rotation.x, J[n].rotation.y, J[n].rotation.z];
    fromY = lastY; fromFist = lastFist;
    anim = name; time = 0; blend = 0;
  }

  function update(dt = 1 / 60) {
    time += dt;
    if (blend < 1) blend = Math.min(1, blend + dt / 0.25);
    const e = blend * blend * (3 - 2 * blend);
    const pose = ANIMS[anim].f(time % ANIMS[anim].dur);
    for (const n of JOINTS) {
      const tgt = pose[n] || REST[n] || [0, 0, 0];
      const f = from[n] || tgt;
      J[n].rotation.set(f[0] + (tgt[0] - f[0]) * e, f[1] + (tgt[1] - f[1]) * e, f[2] + (tgt[2] - f[2]) * e);
    }
    lastY = fromY + ((pose.y || 0) - fromY) * e;
    pelvis.position.set(pose.px || 0, PELVIS_Y + lastY, pose.pz || 0);
    lastFist = fromFist + ((pose.fist ?? 0.3) - fromFist) * e;
    setFist('L', lastFist); setFist('R', lastFist);
    // parpadeo
    blinkT -= dt;
    const closed = blinkT > 0 && blinkT < 0.11;
    for (const { lidU } of eyes) lidU.rotation.x = closed ? 1.55 : 0.35;
    if (blinkT <= 0) blinkT = 2.5 + Math.random() * 3;
  }

  // para hornear animaciones (GLB): fija el tiempo exacto
  function sample(name, t) {
    anim = name; blend = 1; time = t; update(0);
  }

  update(0);
  root.userData = {
    joints: J,
    play,
    update,
    sample,
    getAnimation: () => anim,
    animations: Object.fromEntries(Object.entries(ANIMS).map(([k, v]) => [k, v.dur])),
    speeds: { walk: 1.45, run: 5.2 },
    seatHeight: PELVIS_Y,
    setFist,
  };
  return root;
}
