# Distrito 593

Juego de mundo abierto en 3D, estilo GTA San Andreas, ambientado en Quito, Ecuador.
Juegas como **Brayan Pilataxi**, recién salido de la cárcel por un cilindro de gas que no era suyo, y vas subiendo desde el barrio.

Todo el juego es un solo archivo `index.html` hecho con [three.js](https://threejs.org/) r128. Funciona en PC, iPad, Android y teléfonos, con teclado y mouse, pantalla táctil o control.

## Cómo jugar

- **En línea:** abre `index.html` en el navegador. Si activas GitHub Pages en este repositorio (Settings → Pages → rama `main`), el juego queda publicado en `https://<tu-usuario>.github.io/<repo>/`.
- **En tu computadora:** descarga el repositorio y abre `index.html`. Necesita internet para cargar three.js y las fuentes.

## Controles

| Acción | Teclado y mouse | Control (Xbox / PlayStation) | Táctil |
|---|---|---|---|
| Moverse / manejar | WASD | Stick izquierdo | Joystick |
| Cámara | Mouse | Stick derecho | Arrastrar a la derecha |
| Golpear / disparar | Clic izquierdo o F | RT o X | GOLPE / DISPARAR |
| Apuntar | Clic derecho | LT | APUNTAR |
| Acelerar / frenar | W / S | RT / LT | GAS / FRENO |
| Saltar / freno de mano | Espacio | A | SALTAR / DERRAPE |
| Correr | Shift | B (mantener) o L3 | CORRER |
| Entrar, salir, tienda, vender | E | Y | Botón amarillo |
| Cambiar arma | Q o 1–0 | LB / RB | Tocar el arma |
| Recargar | R | D-pad abajo | — |
| Trabajo | T | D-pad arriba | TRABAJO |
| Robar teléfono / plata | G / H | D-pad izquierda / derecha | Botones del asalto |
| Menú de armas | Tab | Back / View | Tocar el arma |
| Pausa | — | Start / Options | ☰ MENÚ |
| Partidas | M | Desde la pausa | Desde ☰ MENÚ |

## Qué tiene

- **Mapa de Quito:**
  - Barrios: La Carolina, La Mariscal, Centro Histórico y Chimbacalle.
  - Lugares: Basílica del Voto Nacional, Plaza Grande, Panecillo, teleférico, laderas llenas de casas y calles con nombres reales.
  - Las salidas de la ciudad están "en mantenimiento".
- **Historia:**
  - Capítulo 1, Chimbacalle: 5 misiones.
  - Capítulo 2, Centro Histórico: 3 misiones.
  - Personajes: El Flaco, Yessi, Doña Rosi, el Tío Bala y El Diputado.
- **Trabajos:** taxista, repartidor, carreras callejeras, asalto al camión de valores y chiva rumbera con música.
- **Combate:**
  - 11 armas, desde los puños hasta el lanzacohetes.
  - Armería bajo el Puente Inconcluso.
  - Los enemigos tienen animaciones de ataque.
- **Policía y pandillas:**
  - Estrellas de búsqueda.
  - Pandillas: Los Ñaños del Sur y Los Pelucones.
- **Asaltos:** apuntas a un peatón, le robas el teléfono o la plata, y vendes los teléfonos en las compraventas.
- **Ciudad viva:**
  - Tráfico con semáforos, trole, ambulancias y bomberos.
  - Clima con lluvia y ciclo de día y noche.
  - Luces reales en los postes.
- **Opciones:**
  - 4 ranuras de guardado.
  - 3 dificultades.
  - 3 niveles de gráficos.
- **Personajes jugables:**
  - Brayan Pilataxi.
  - Esteban Benavides, que se desbloquea con un código.

## Códigos

Escríbelos mientras juegas o en el botón **CÓDIGO**:

- `polijaja` — todas las armas, munición infinita y $9.999.999 (escríbelo otra vez para quitarlo)
- `fefasa` — activa las estrellas de búsqueda
- `estbena` — desbloquea a Esteban Benavides

## Archivos

```
index.html               el juego completo
modelos/esteban-593.js   modelo 3D original de Esteban (three.js moderno, módulo ES)
```

`index.html` ya trae una versión adaptada del modelo de Esteban a three.js r128. El archivo de `modelos/` es la fuente original.

Las partidas se guardan en el navegador (`localStorage`).

## Créditos

Creado por Esteban Benavides.
